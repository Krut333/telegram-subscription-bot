import os
from datetime import datetime, timedelta
from flask import Flask, request
import telebot

TOKEN = os.getenv("BOT_TOKEN")
bot = telebot.TeleBot(TOKEN)
app = Flask(__name__)

# Память подписок
subscriptions = {}

# Команда старт
@bot.message_handler(commands=['start'])
def start(message):
    bot.send_message(message.chat.id, "Добро пожаловать! Используйте /subscribe <дни> для активации доступа.")

# Команда подписки
@bot.message_handler(commands=['subscribe'])
def subscribe(message):
    try:
        _, days = message.text.split()
        days = int(days)
        expire = datetime.now() + timedelta(days=days)
        subscriptions[message.chat.id] = expire
        bot.send_message(message.chat.id, f"Подписка активирована на {days} дней до {expire.strftime('%Y-%m-%d %H:%M:%S')}")
    except:
        bot.send_message(message.chat.id, "Неверный формат. Пример: /subscribe 30")

# Проверка доступа
@bot.message_handler(func=lambda m: True)
def check_access(message):
    expire = subscriptions.get(message.chat.id)
    if not expire or expire < datetime.now():
        bot.send_message(message.chat.id, "У вас нет активной подписки. Используйте /subscribe <дни>")
    else:
        bot.send_message(message.chat.id, "Доступ разрешён ✅")

# Webhook
@app.route(f"/{TOKEN}", methods=["POST"])
def webhook():
    json_str = request.get_data().decode("UTF-8")
    update = telebot.types.Update.de_json(json_str)
    bot.process_new_updates([update])
    return "!", 200

# Главная страница
@app.route("/")
def index():
    return "Бот работает."

if __name__ == "__main__":
    app.run()
